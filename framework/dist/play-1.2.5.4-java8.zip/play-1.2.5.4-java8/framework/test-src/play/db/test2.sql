CREATE TABLE test(name varchar);
CREATE TABLE test2(name varchar)